import { buildWebsiteBaseString, md5, htmlForm } from './_pf.js';

export default function handler(req, res) {
  try {
    // Environment variables
    const merchantId = process.env.PAYFAST_MERCHANT_ID || '30416437';
    const merchantKey = process.env.PAYFAST_MERCHANT_KEY || 'pad4oqiwqejc2';
    const passphrase = process.env.PAYFAST_PASSPHRASE || 'Allcarerecruitment6';
    const appBaseUrl = process.env.APP_BASE_URL || 'https://careca-yankavanwyk.replit.app';
    const pfHost = 'https://www.payfast.co.za/eng/process';

    // Extract user data from query params or default values
    const nameFirst = req.query.name_first || req.body?.name_first || 'User';
    const nameLast = req.query.name_last || req.body?.name_last || 'Name';
    const emailAddress = req.query.email_address || req.body?.email_address || 'user@example.com';

    // Generate unique payment ID
    const paymentId = `pf_${Date.now()}_${Math.random().toString(36).substr(2, 8)}`;

    // Calculate billing date (tomorrow)
    const billingDate = new Date();
    billingDate.setDate(billingDate.getDate() + 1);
    const billingDateStr = billingDate.toISOString().split('T')[0];

    // PayFast form fields in exact order
    const fields = {
      merchant_id: merchantId,
      merchant_key: merchantKey,
      return_url: `${appBaseUrl}/ok`,
      cancel_url: `${appBaseUrl}/cancel`,
      notify_url: `${process.env.GATEWAY_BASE_URL || req.headers.host}/api/notify`,
      name_first: nameFirst,
      name_last: nameLast,
      email_address: emailAddress,
      m_payment_id: paymentId,
      amount: '60.00',
      item_name: 'Subscription',
      payment_method: 'cc',
      subscription_type: '1',
      billing_date: billingDateStr,
      recurring_amount: '60.00',
      frequency: '3',
      cycles: '0'
    };

    // Generate signature
    const baseString = buildWebsiteBaseString(fields, passphrase);
    const signature = md5(baseString);
    fields.signature = signature;

    console.log(`[GATEWAY] Payment form generated for ${emailAddress}, signature: ${signature}`);

    // Generate and return HTML form
    const formHtml = htmlForm(pfHost, fields);
    
    res.setHeader('Content-Type', 'text/html');
    res.status(200).send(formHtml);

  } catch (error) {
    console.error('[GATEWAY] Error creating subscription:', error);
    res.status(500).json({ 
      error: 'Failed to create subscription',
      message: error.message 
    });
  }
}