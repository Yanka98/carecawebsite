import { itnSignature } from './_pf.js';
import crypto from 'crypto';

// Raw body parser for webhooks
function getRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Get raw body for signature validation
    const rawBody = await getRawBody(req);
    const bodyString = rawBody.toString('utf8');
    
    // Parse form data
    const params = new URLSearchParams(bodyString);
    const data = Object.fromEntries(params.entries());
    
    console.log('[GATEWAY ITN] Received notification:', {
      payment_status: data.payment_status,
      m_payment_id: data.m_payment_id,
      amount_gross: data.amount_gross,
      pf_payment_id: data.pf_payment_id
    });

    // Validate signature
    const passphrase = process.env.PAYFAST_PASSPHRASE || 'Allcarerecruitment6';
    const expectedSig = itnSignature(data, passphrase);
    const receivedSig = data.signature;
    
    if (expectedSig !== receivedSig) {
      console.error('[GATEWAY ITN] Signature mismatch:', {
        expected: expectedSig,
        received: receivedSig
      });
      return res.status(400).json({ error: 'Invalid signature' });
    }

    // Validate IP (PayFast IPs)
    const allowedIPs = [
      '197.97.145.144', '41.74.179.194', '41.74.179.195', '41.74.179.196',
      '41.74.179.197', '41.74.179.198', '41.74.179.199', '196.33.241.20'
    ];
    
    const clientIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    if (!allowedIPs.some(ip => clientIP?.includes(ip))) {
      console.warn('[GATEWAY ITN] Suspicious IP:', clientIP);
    }

    // Process valid notification
    if (data.payment_status === 'COMPLETE') {
      console.log('[GATEWAY ITN] Payment completed:', {
        payment_id: data.m_payment_id,
        amount: data.amount_gross,
        pf_payment_id: data.pf_payment_id,
        token: data.token
      });

      // Forward to main app if needed
      const appBaseUrl = process.env.APP_BASE_URL;
      if (appBaseUrl) {
        try {
          const response = await fetch(`${appBaseUrl}/api/payfast/notify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: bodyString
          });
          console.log('[GATEWAY ITN] Forwarded to main app:', response.status);
        } catch (err) {
          console.error('[GATEWAY ITN] Failed to forward:', err.message);
        }
      }
    }

    // Always respond OK to PayFast
    res.status(200).send('OK');

  } catch (error) {
    console.error('[GATEWAY ITN] Processing error:', error);
    res.status(500).json({ error: 'Processing failed' });
  }
}