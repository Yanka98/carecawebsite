export default function handler(req, res) {
  const status = {
    status: 'healthy',
    service: 'PayFast Gateway',
    timestamp: new Date().toISOString(),
    environment: process.env.PAYFAST_MODE || 'live',
    merchant_id: process.env.PAYFAST_MERCHANT_ID || '30416437',
    aws_ready: true,
    endpoints: {
      create_subscription: '/api/create-subscription',
      notify: '/api/notify',
      health: '/api/health'
    }
  };

  res.status(200).json(status);
}